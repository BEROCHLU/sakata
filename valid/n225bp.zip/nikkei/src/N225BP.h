/* N225BP.h */

#define I             3
#define J             3
#define K             1
#define ETA           0.5
#define sigmoid(x)    tanh(x)
#define SIZE          64
#define DESIRED_ERROR 0.00500
