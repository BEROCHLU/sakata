
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>
#include <time.h>
#include "N225BP.h"

void Initialization(void);
void FindHiddenOutput(int);
void PrintResult(void);
void PrintVW(void);
double FrandFix(void);

int q=0,days;
char date[SIZE][12];
double DOWdiv=0,FXdiv=0,N225div=0;
double x[SIZE][I],t[SIZE][K];
double v[J][I],w[K][J],H[J],o[K];

int main(){

	int i,j,k,p;
	double DOW[SIZE] = {0};
	double FX[SIZE] = {0};
	double N225[SIZE] = {0};
	double Error = DBL_MAX;
	double preError = 1024;
	double delta_o[K],delta_H[J];

	FILE *fp;
	clock_t start,end;
	time_t timer;

	if( (fp = fopen("N225BP.csv","r") ) == NULL)
	{
		 printf("The file doesn't exist!\n"); exit(1);
	}

	for(i=0; EOF!=fscanf(fp,"%[^,],%lf,%lf,%lf",date[i],&DOW[i],&FX[i],&N225[i]); i++)
	{
		if(0<i)
		{
			DOW[i-1] = (DOW[i]/DOW[i-1])*100;
			FX[i-1] = (FX[i]/FX[i-1])*100;
			N225[i-1] = (N225[i]/N225[i-1])*100;

			if(DOWdiv < DOW[i-1]) DOWdiv = DOW[i-1];
			if(FXdiv < FX[i-1]) FXdiv = FX[i-1];
			if(N225div < N225[i-1]) N225div = N225[i-1];

			if(!DOW[i] || !FX[i] || !N225[i])
			{
				break;
			}

		}
	}

	days = i-1;

	fclose(fp);

/* 入力データの最大値に期待値誤差を加えて除数とする */
	DOWdiv = DOWdiv*(1+DESIRED_ERROR);
	FXdiv = FXdiv*(1+DESIRED_ERROR);
	N225div = N225div*(1+DESIRED_ERROR);

	for(i=0; i<days; i++)
	{
		x[i][0] = DOW[i]/DOWdiv;
		x[i][1] = FX[i]/FXdiv;
		x[i][2] = -1;
		t[i][0] = N225[i]/N225div;
	}

	Initialization();
	PrintVW();

	time(&timer);
	printf("%s",ctime(&timer) );

	start = clock();

	while(DESIRED_ERROR < Error)
	{
		q++; Error=0;

		for(p=0; p<days; p++)
		{
			FindHiddenOutput(p);
		/* 最小二乗法での誤差を定義 */
			for(k=0; k<K; k++)
			{
				Error += 0.5*pow(t[p][k]-o[k], 2.0);
				delta_o[k]=(t[p][k]-o[k])*(1-o[k])*o[k];
			}
			//丸め

			for(j=0; j<J; j++)
			{
				delta_H[j]=0;

				for(k=0; k<K; k++)
				{
					delta_H[j] += delta_o[k]*w[k][j];
				}

				delta_H[j]=(1-H[j])*H[j]*delta_H[j];
			}

			for(k=0; k<K; k++)
			{/* 出力層の結合荷重の修正量 */
				for(j=0; j<J; j++)
				{
					w[k][j] += ETA*delta_o[k]*H[j];
				}
			}

			for(j=0; j<J; j++)
			{/* 中間層の結合荷重の修正量 */
				for(i=0; i<I; i++)
				{
					v[j][i] += ETA*delta_H[j]*x[p][i];
				}
			}
		}

		Error = Error*pow(10,5);
		Error = (int)Error;

		if(q%1000 == 0)
		{
			printf("%6d: %f\n",q,Error);

			if(1000000 < Error)
			{
				printf("Over Error %d: %f\n",q,Error);
				exit(0);
			}
			else if(preError*4 < Error)
			{
				printf("Over Learning %lf %lf\n",Error,preError);
				exit(0);
			}

			preError = Error;

		}

		Error = Error*pow(10,-5);
	}

	end = clock();

	/* 学習結果を表示 */
	PrintResult();

	/* バックアップの為に重みをファイル出力 */
	/**
	fp = fopen("N225BPweight.dat","w");
	for(j=0; j<J; j++)
	{
		fprintf(fp,"%5lf\n",w[0][j]);
	}
	for(j=0; j<J-1; j++)
	{
		fprintf(fp,"%5lf %5lf %5lf\n",v[j][0],v[j][1],v[j][2]);
	}
	fclose(fp);
	*/

	printf("Time %.2lfsec.\n",(double)(end-start)/CLOCKS_PER_SEC);

	return 0;
}

/* Initialization of the connection weights */
void Initialization(void)
{
	int i,j,k;

	srand( (unsigned int)time(NULL) );/**現在時刻を元に種を生成*/

	for(j=0; j<J; j++)
	{/* 中間層の結合荷重を初期化 */
		/*range (-0.5 -> 0.5)*/
		for(i=0; i<I; i++)
		{
			v[j][i] = FrandFix()-0.5;
		}
	}

	for(k=0; k<K; k++)
	{/* 出力層の結合荷重の初期化 */
		for(j=0; j<J; j++)
		{
			w[k][j] = FrandFix()-0.5;
		}
	}
}

/* Find the output of hidden and output neurons */
void FindHiddenOutput(int p)
{
	int i,j,k; double T,U;

	for(j=0; j<J-1; j++)
	{
		T=0;

		for(i=0; i<I; i++)
		{
			T += v[j][i]*x[p][i];
		}

		H[j]=sigmoid(T);
	}

	H[J-1]=-1;

	for(k=0; k<K; k++)
	{
		U=0;

		for(j=0;j<J;j++)
		{
			U += w[k][j]*H[j];
		}

		o[k]=sigmoid(U);
	}
}

/* Print out the final result */
void PrintResult(void)
{
	int i;
	double Esum=0,Erate[SIZE],valance=0;
	double valanceMin=DBL_MAX,valanceMax=DBL_MIN;

	for(i=0; i<days; i++)
	{
		FindHiddenOutput(i);

		Erate[i] = (t[i][0]-o[0])/t[i][0]*100;

		valance += Erate[i];

		printf("%10s %6.2lf True %6.2lf Error %5.2lf%% %5.2lf",date[i+1],o[0]*N225div,t[i][0]*N225div,Erate[i],valance);

		Erate[i] = fabs(Erate[i]);

		Esum += Erate[i];

		if(valance < valanceMin) valanceMin = valance;
		if(valanceMax < valance) valanceMax = valance;
	}

	printf("\nAverage error = %.2lf%%\n",Esum/days);
	printf("Min = %.2lf Max = %.2lf Mid = %.2lf\n",valanceMin,valanceMax,(valanceMin+valanceMax)/2);
	//PrintVW();

}

void PrintVW(void)
{
	int j;

	printf("w = %5lf %5lf %5lf\n",w[0][0],w[0][1],w[0][2]);

	for(j=0; j<J-1; j++)
	{
		printf("v = %5lf %5lf %5lf\n",v[j][0],v[j][1],v[j][2]);
	}
}

/**fix same seed issue of random number*/
double FrandFix(void)
{
	int i;
	double drand;

	/**乱数を複数回生成して最後の値を使用する*/
	for(i=0; i<8; i++)
	{
		drand = rand()%10000/10001.0;
	}

	return drand;
}
